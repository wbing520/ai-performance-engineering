# NIXL Asynchronous GPU-to-GPU Transfer Example

This example demonstrates using NVIDIA's NIXL library to transfer data between two GPUs asynchronously, overlapping computation and communication.

## Hardware & Software Requirements

- **GPUs:** GB100/GB200 (Grace-Blackwell) or fallback H100 (Hopper)  
- **CUDA Toolkit:** 13.0 or later  
- **C++ Compiler:** nvcc with C++17 support  
- **Dependencies:**  
  - NIXL library and headers installed (e.g., `libnixl.so`, `nixl.h`)  
  - CUDA Runtime  
  - pthreads  

- **Profiling Tools:**  
  - Nsight Systems 2025.2.1 (`nsys`)  
  - Nsight Compute 2024.3 (`ncu`)

## Building

```bash
cd nixl_transfer_example
make
```

This builds the `nixl_transfer` executable.

## Running

Adjust `NIXL_SOCKET_IFNAME` and any env vars if needed, then:

```bash
# Example: transfer 32 MB
./nixl_transfer 33554432
```

The program initializes two NIXL agents, registers memory, posts an asynchronous transfer, does dummy work, waits for completion, verifies correctness, and exits.

## Profiling

### Nsight Systems

```bash
./run_nsys.sh
```

Generates `nsys_nixl_transfer.qdrep`.

### Nsight Compute

```bash
./run_ncu.sh
```

Generates `ncu_nixl_transfer_report.ncu-rep`.

Open these in the Nsight GUI to inspect timeline overlap and kernel details.
