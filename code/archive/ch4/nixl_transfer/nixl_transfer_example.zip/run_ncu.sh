#!/usr/bin/env bash
# Profile the NIXL transfer example with Nsight Compute
ncu     --target-processes all     --set full     --launch-skip 0     --launch-count 1     --output ncu_nixl_transfer_report     ./nixl_transfer 33554432
