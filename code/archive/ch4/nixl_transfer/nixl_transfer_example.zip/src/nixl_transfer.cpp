// nixl_transfer.cpp
// Example: Asynchronous GPU-to-GPU transfer using NIXL

#include <nixl.h>
#include <cuda_runtime.h>
#include <iostream>
#include <thread>
#include <cassert>

void dummy_compute(int device, int iterations) {
    cudaSetDevice(device);
    const int N = 1 << 20;
    float *buf;
    cudaMalloc(&buf, N * sizeof(float));
    for (int i = 0; i < iterations; ++i) {
        // Simple compute dummy: memset
        cudaMemset(buf, i % 256, N * sizeof(float));
    }
    cudaFree(buf);
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <data_size_bytes>\n";
        return 1;
    }
    size_t dataSize = std::stoul(argv[1]);

    int srcDev = 0, dstDev = 1;
    cudaSetDevice(srcDev);
    float *srcPtr;
    cudaMalloc(&srcPtr, dataSize);
    cudaSetDevice(dstDev);
    float *dstPtr;
    cudaMalloc(&dstPtr, dataSize);

    nixlAgentHandle agentSrc, agentDst;
    nixlInitAgent(&agentSrc);
    nixlInitAgent(&agentDst);

    nixlMemHandle memSrc, memDst;
    nixlRegisterMemory(agentSrc, srcPtr, dataSize, &memSrc);
    nixlRegisterMemory(agentDst, dstPtr, dataSize, &memDst);

    nixlXferRequest req;
    nixlCreateXferRequest(agentSrc, NIXL_WRITE, memSrc, agentDst, memDst, &req);
    nixlSetNotification(req, agentDst, "transfer_done");

    nixlStatus status = nixlPostRequest(req);
    assert(status == NIXL_SUCCESS);
    std::cout << "Transfer posted, running dummy compute concurrently...\n";

    dummy_compute(srcDev, 100);

    while (!nixlPollNotification(agentSrc, "transfer_done")) {
        std::this_thread::yield();
    }
    std::cout << "Transfer completed.\n";

    nixlReleaseRequest(req);
    nixlDeregisterMemory(memSrc);
    nixlDeregisterMemory(memDst);
    cudaFree(srcPtr);
    cudaFree(dstPtr);
    nixlShutdownAgent(agentSrc);
    nixlShutdownAgent(agentDst);

    return 0;
}
