#!/usr/bin/env bash
# Profile the NIXL transfer example with Nsight Systems
nsys profile     --trace=cuda,nvtx     --sample none     --output nsys_nixl_transfer     ./nixl_transfer 33554432
